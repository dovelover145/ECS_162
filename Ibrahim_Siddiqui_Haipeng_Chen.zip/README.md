# Notes

### 1. Go to the backend directory and run `python app.py`, and follow the specified link

### 2. To run the Javascript unit tests for the business logic, go to the tests directory and run `npm test`

### 3. To run the unit tests for the Flask backend, go to the tests directory and run `pytest test_app.py`